FontAwesomeConfig = { searchPseudoElements: true };
