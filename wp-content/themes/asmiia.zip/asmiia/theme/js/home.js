$(document).ready(function(){
	$('.quienes').on("click",function(){
		$('.quienes').toggleClass('comprimido');
	});
});